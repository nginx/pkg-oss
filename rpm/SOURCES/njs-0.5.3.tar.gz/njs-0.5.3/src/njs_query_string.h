
/*
 * Copyright (C) Alexander Borisov
 * Copyright (C) NGINX, Inc.
 */

#ifndef _NJS_QUERY_STRING_H_INCLUDED_
#define _NJS_QUERY_STRING_H_INCLUDED_

extern const njs_object_init_t  njs_query_string_object_init;

#endif /* _NJS_QUERY_STRING_H_INCLUDED_ */
